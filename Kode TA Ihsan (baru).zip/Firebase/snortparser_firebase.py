# Module Imports
import sys
import os
from pathlib import Path
from datetime import date
from xml.etree.ElementTree import tostring
import pyparsing as pyp
import itertools
import schedule
import time

import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
# Fetch the service account key JSON file contents
cred = credentials.Certificate('/home/ihsanfr/Downloads/Kode_TA_Ihsan/Firebase/ta-ihsan-firebase-adminsdk-dqlgz-233439b4b0.json')
# Initialize the app with a service account, granting admin privileges
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://ta-ihsan-default-rtdb.firebaseio.com/'
})

ref = db.reference('snort_log')


def add_data(SID, Pesan_Alert, Prioritas, Timestamp, Port, IP_Address):
    value = {
        "SID" : SID,
        "Pesan_Alert" : Pesan_Alert,
        "Prioritas" : Prioritas,
        "Timestamp" : Timestamp,
        "Port" : Port,
        "IP_Address" : IP_Address
    }
    ref.push().set(value)

integer = pyp.Word(pyp.nums)
string = pyp.Word(pyp.alphas)
ip_addr = pyp.Combine(integer+'.'+integer+'.'+integer+'.'+integer)

def snort_parse(logfile):
    header = (pyp.Suppress("[**] [" + integer + ":")
              + pyp.Combine(integer)
              )
    cls = ( pyp.Suppress(":" + integer +"]") +
        pyp.Regex("[^[]*") +pyp.Suppress("[**]"))
    
    pri = pyp.Suppress("[Priority:") + integer + pyp.Suppress("]")
    date = pyp.Combine(
        integer+"/"+integer+'-'+integer+':'+integer+':'+integer+'.'+integer)
    network = pyp.Combine(ip_addr + pyp.SkipTo("-> ", include = True) + ip_addr) 
    port =  pyp.Combine(pyp.Suppress(":") + integer +pyp.Suppress("\n"))
    ip = pyp.Regex("([A-Z])\w+")

    bnf = header +cls +pri + date+ network+port
    

    with open(logfile) as snort_logfile:
        for has_content, grp in itertools.groupby(snort_logfile, key = lambda x: bool(x.strip())):
            if has_content:
                tmpStr = ''.join(grp)
                id = header.searchString(tmpStr)
                kelas = cls.searchString(tmpStr)
                prior = pri.searchString(tmpStr)
                tgl = date.searchString(tmpStr)
                jaringan = network.searchString(tmpStr)
                plbhn = port.searchString(tmpStr)
                strippedid = str(id).replace("[['", "").replace("']]", "")
                strippedkelas = str(kelas).replace("[['", "").replace("']]", "")
                strippedprior = str(prior).replace("[['", "").replace("']]", "")
                strippedtgl = str(tgl).replace("[['", "").replace("']]", "")
                strippedjaringan = str(jaringan).replace("[['", "").replace("']]", "")
                strippedplbhn = str(plbhn).replace("[['", "").replace("']]", "")
                print(strippedid, strippedkelas, strippedprior, strippedtgl, strippedplbhn, strippedjaringan)
                add_data(strippedid, strippedkelas, strippedprior, strippedtgl, strippedplbhn, strippedjaringan)
snort_parse("/home/ihsanfr/Downloads/alert1.txt")