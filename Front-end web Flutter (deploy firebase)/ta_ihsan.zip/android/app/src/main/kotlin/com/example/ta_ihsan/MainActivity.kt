package com.example.ta_ihsan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
